# app/views.py

from flask import Blueprint, render_template, request, current_app, jsonify
from SPARQLWrapper import SPARQLWrapper, JSON
from SPARQLWrapper.SPARQLExceptions import Unauthorized

main = Blueprint('main', __name__)

@main.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@main.route('/query', methods=['POST'])
def query():
    try:
        # Get the SPARQL query from the form
        query_text = request.form['query']

        # Print the query for debugging
        current_app.logger.info("SPARQL Query: %s", query_text)

        # Connect to the GraphDB with credentials
        endpoint = 'http://DESKTOP-LTTMNGV:7200/repositories/KO9'
        sparql = SPARQLWrapper(endpoint)
        sparql.setCredentials("admin", "root")  # Replace with your GraphDB credentials
        sparql.setQuery(query_text)
        sparql.setReturnFormat(JSON)

        # Execute the SPARQL query
        results = sparql.query().convert()

        # Log the query results
        current_app.logger.info("Query Results: %s", results)

        # Render the results using the 'results.html' template
        return render_template('results.html', results=results['results']['bindings'] if results else None)

    except Unauthorized as e:
        # Log the specific unauthorized exception
        current_app.logger.error("Unauthorized access to GraphDB endpoint: %s", e)
        return jsonify({'error': 'Unauthorized access to the GraphDB endpoint. Check your credentials.'}), 401

    except Exception as e:
        # Log other exceptions
        current_app.logger.error("Error executing SPARQL query: %s", e, exc_info=True)
        return jsonify({'error': 'An error occurred while processing the query.'}), 500
