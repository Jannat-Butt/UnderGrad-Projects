# app/__init__.py

from flask import Flask
from flask_cors import CORS

def create_app():
    app = Flask(__name__)

    # Enable CORS for all routes (remove this in production if not needed)
    CORS(app)

    # Register the 'main' blueprint
    from .views import main
    app.register_blueprint(main)

    return app
