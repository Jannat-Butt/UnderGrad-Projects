# run.py

import logging
from app import create_app

app = create_app()

# Enable logging
logging.basicConfig(level=logging.DEBUG)

if __name__ == '__main__':
    app.run(debug=True)
